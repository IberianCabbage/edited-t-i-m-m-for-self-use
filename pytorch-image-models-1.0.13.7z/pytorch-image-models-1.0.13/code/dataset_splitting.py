"""
将已调整为ImageNet格式的数据集划分为训练、验证、测试集
"""

import shutil
from BaseDT.dataset import DataSet

source_dir = r'./data/classified_Train'
new_dir = r'./data/train'

ds = DataSet(new_dir)  # 指定为生成新数据集的路径
# 默认比例为train_ratio = 0.7, test_ratio = 0.1, val_ratio = 0.2
ds.make_dataset(source_dir, src_format="IMAGENET", train_ratio=0.8, test_ratio=0,
                val_ratio=0.2)  # 指定原始数据集的路径，数据集格式选择IMAGENET

# 删除转换前的文件夹
print("\nDeleting original files...")
shutil.rmtree(source_dir)
print("Original files have been deleted.")
