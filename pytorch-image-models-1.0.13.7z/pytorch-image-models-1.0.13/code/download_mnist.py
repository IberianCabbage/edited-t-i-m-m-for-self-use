"""
下载MNIST数据集，并将其转化为jpg格式存储到本地，并调整为ImageNet的数据集格式
"""

import os
import torch
from torchvision import datasets, transforms
from PIL import Image


def download_mnist():
    # 下载MNIST数据集
    # 定义数据集的保存路径
    dataset_path = './mnist_raw'
    # 定义数据转换：将图片转为Tensor
    transform = transforms.Compose([transforms.ToTensor()])
    # 下载并加载训练集
    mnist_train = datasets.MNIST(root=dataset_path, train=True, download=True, transform=transform)

    # 创建存储图片的根目录
    output_dir = './mnist_jpg/images'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    # 创建并保存类别目录
    class_names = [str(i) for i in range(10)]  # MNIST有10个类别，分别是0到9
    class_dirs = {}
    for class_name in class_names:
        class_dir = os.path.join(output_dir, class_name)
        if not os.path.exists(class_dir):
            os.makedirs(class_dir)
        class_dirs[class_name] = class_dir

    # 保存每张图片为JPEG格式，按照类别分类
    for i, (image, label) in enumerate(mnist_train):
        # 将Tensor转换为PIL图片
        image = transforms.ToPILImage()(image)
        # 图片文件的保存路径
        class_dir = class_dirs[str(label)]  # 根据标签找到对应类别的文件夹
        image_path = os.path.join(class_dir, f'{i}.jpg')
        # 保存为JPEG文件
        image.save(image_path, 'JPEG')
        # 打印保存进度
        if i % 1000 == 0:
            print(f'Saved {i} images...')

    # 保存类别名称到 classes.txt 文件
    classes_file_path = os.path.join('mnist_jpg/classes.txt')
    with open(classes_file_path, 'w') as f:
        for class_name in class_names:
            f.write(f'{class_name}\n')

    print(f"Finished saving {len(mnist_train)} images to {output_dir}")
    print(f"Class names are saved to {classes_file_path}")


def main():
    # 下载并整理MNIST数据集
    download_mnist()


if __name__ == '__main__':
    main()
