from sklearn.metrics import confusion_matrix
import os
import numpy as np
import pandas as pd

output_path = 'output'
top_k = 5  # 保存前top_k名的结果


def category_inf(conf_matrix):
    # 计算每个类别的指标
    num_classes = conf_matrix.shape[0]
    class_metrics = []

    for i in range(num_classes):
        TP = conf_matrix[i, i]  # True Positive
        FP = conf_matrix[:, i].sum() - TP  # False Positive
        FN = conf_matrix[i, :].sum() - TP  # False Negative
        TN = conf_matrix.sum() - (TP + FP + FN)  # True Negative

        accuracy = TP / (TP + FP + FN) if (TP + FP + FN) > 0 else 0
        precision = TP / (TP + FP) if (TP + FP) > 0 else 0
        recall = TP / (TP + FN) if (TP + FN) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        sample_count = TP + FN  # 总样本数
        proportion = sample_count / conf_matrix.sum()  # 类别比例

        # 获取 Top-5 预测类别及其对应的预测数量（假设此时为概率）
        top5_idx = np.argsort(conf_matrix[i, :])[::-1][:5]  # 获取预测最多的前5个类别
        top5_prob = conf_matrix[i, top5_idx] / sample_count if sample_count > 0 else 0  # 概率

        # 创建一个包含 Top-5 类别和预测概率的字典
        top5_info = {f'Most_{j + 1}': top5_idx[j] for j in range(5)}
        top5_prob_info = {f'{j + 1}_Probability': top5_prob[j] for j in range(5)}

        # 将该类别的指标和 Top-5 信息整合
        class_data = {
            'Class': i,
            'Count': sample_count,
            'Proportion': proportion,
            # 'Top1 Accuracy': [element[k] / sum(element) for k, element in enumerate(conf_matrix)],
            'Top1 Acc': conf_matrix[i][i] / sample_count,
        }

        data2 = {
            'TP': TP,
            'FP': FP,
            'FN': FN,
            'TN': TN,
            'Accuracy': accuracy,
            'Precision': precision,
            'Recall': recall,
            'F1 Score': f1
        }

        # 合并 Top-5 信息到 data1
        class_data.update(top5_info)
        class_data.update(top5_prob_info)
        class_data.update(data2)
        class_metrics.append(class_data)

    # 4. 整体指标计算
    class_metrics_df = pd.DataFrame(class_metrics)

    # 加权平均
    weighted_precision = np.average(class_metrics_df['Precision'], weights=class_metrics_df['Count'])
    weighted_recall = np.average(class_metrics_df['Recall'], weights=class_metrics_df['Count'])
    weighted_f1 = np.average(class_metrics_df['F1 Score'], weights=class_metrics_df['Count'])

    # 宏平均
    macro_precision = class_metrics_df['Precision'].mean()
    macro_recall = class_metrics_df['Recall'].mean()
    macro_f1 = class_metrics_df['F1 Score'].mean()

    # 添加整体指标到 DataFrame
    overall_metrics = pd.DataFrame({
        'Metric': ['Weighted Precision', 'Weighted Recall', 'Weighted F1 Score',
                   'Macro Precision', 'Macro Recall', 'Macro F1 Score'],
        'Value': [weighted_precision, weighted_recall, weighted_f1,
                  macro_precision, macro_recall, macro_f1]
    })

    # 5. 返回 CSV 帧
    return class_metrics_df, overall_metrics


def main():
    if not os.path.exists(output_path):
        os.makedirs(output_path)
    inf_file = os.path.join(output_path, 'inference.csv')

    df = pd.read_csv(inf_file)
    labels = []
    top1 = []
    topk = []
    indices = []
    top1_correct = []
    topk_correct = []

    # 提取数据
    for index, row in df.iterrows():
        label = int(row['Label'])
        labels.append(label)

        numbers = row['Predicted'].strip().split()  # 去除行末的换行符，并按空格分割成列表
        numbers = [float(num) for num in numbers]

        # 使用enumerate获取元素的索引和值，然后根据值进行排序
        sorted_with_index = sorted(enumerate(numbers), key=lambda x: x[1], reverse=True)
        top1_result = sorted_with_index[0][0]
        topk_result = sorted_with_index[:top_k]
        top1.append(top1_result)
        topk.append(topk_result)
        top1_correct.append(True if top1_result == label else False)
        topk_correct.append(True if label in [k[0] for k in topk_result] else False)

        id = str(row['ID'])
        indices.append(id)

    # 分类别推理
    # 生成混淆矩阵
    cm = confusion_matrix(labels, top1)
    print("Confusion Matrix:")
    print(cm)

    save_path = os.path.join(output_path, 'train_confusion_matrix.txt')
    with open(save_path, 'w') as f:
        for line in cm:
            f.write(' '.join(map(str, line)) + '\n')

    class_metrics_df, overall_metrics = category_inf(cm)

    # 插入一列topk准确率
    topk_acc = [0] * len(cm)
    for index, label in enumerate(labels):
        if topk_correct[index]:
            topk_acc[label] += 1
    topk_acc = [acc / sum(cm[index]) for index, acc in enumerate(topk_acc)]
    class_metrics_df.insert(4, f'Top{top_k} Acc', topk_acc)

    # 输出结果
    class_metrics_df_path = os.path.join(output_path, 'inference_category-wise.csv')
    overall_metrics_path = os.path.join(output_path, 'train_overall_metrics.csv')
    class_metrics_df.to_csv(class_metrics_df_path, index=False)
    overall_metrics.to_csv(overall_metrics_path, index=False)

    print(f"Category-wise inference has been saved to '{class_metrics_df_path}'.")
    print(f"Overall metrics has been saved to '{overall_metrics_path}'.")

    # 分图片推理
    # 合成数据
    data = {
        'ID': indices,
        'Label': labels,
        'Top1_correct': top1_correct,
        f'Top{top_k}_correct': topk_correct
    }
    for i in range(top_k):
        update = {f'Top{i + 1}': [element[i][0] for element in topk]}
        data.update(update)
        update = {f'score{i + 1}': [element[i][1] for element in topk]}
        data.update(update)

    # 文件输出
    image_df = pd.DataFrame(data)
    image_df.to_csv(os.path.join(output_path, 'inference_image-wise.csv'), index=False)
    print(f"Image-wise inference has been saved to '{class_metrics_df_path}'.")


if __name__ == '__main__':
    main()
