# Hugging Face Timm Docs

## Getting Started

```
pip install git+https://github.com/huggingface/doc-builder.git@main#egg=hf-doc-builder
pip install watchdog black
```

## Preview the Docs Locally

```
doc-builder preview timm hfdocs/source
```
