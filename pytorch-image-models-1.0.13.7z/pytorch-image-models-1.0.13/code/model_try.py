import timm
from pprint import pprint  # pprint: 排版更好的print
import sys


def list_models():
    # 获取模型列表
    model_names = timm.list_models(pretrained=True)     # 列举全部模型
    # pprint(model_names)
    model_names2 = timm.list_models('*meta*')     # 根据关键词列举模型
    pprint(model_names2)

    # 导出模型列表到txt文件
    with open('model_list.txt', 'w', encoding='UTF-8') as f:
        for model in model_names2:
            f.write(f'{model}\n')


def process_model_list(input_file, output_file1, output_file2):
    # 读取文件内容
    with open(input_file, 'r') as file:
        lines = file.readlines()

    # 用于存储处理后的行
    processed_lines_first = []
    processed_lines_second = []

    # 用于存储已经出现过的前两个部分
    seen_prefixes = set()

    for line in lines:
        # 去除行尾的换行符
        line = line.strip()

        # 以下划线分割行
        parts = line.split('_')

        # 提取第一个部分
        if len(parts) >= 1:
            prefix1 = '_'.join(parts[:1])

            # 如果前缀没有出现过，则添加到结果中
            if prefix1 not in seen_prefixes:
                seen_prefixes.add(prefix1)
                processed_lines_first.append(prefix1)

        # 提取前两个部分
        if len(parts) >= 2:
            prefix2 = '_'.join(parts[:2])

            # 如果前缀没有出现过，则添加到结果中
            if prefix2 not in seen_prefixes:
                seen_prefixes.add(prefix2)
                processed_lines_second.append(prefix2)

    # 将处理后的行写入输出文件
    with open(output_file1, 'w') as file:
        for line in processed_lines_first:
            file.write(line + '\n')

    with open(output_file2, 'w') as file:
        for line in processed_lines_second:
            file.write(line + '\n')


def main():
    list_models()
    # process_model_list("model_list.txt", "model1.txt", "model2.txt")

    # # 创建模型
    # model_name = 'vit_base_r50_s16_224'
    # m = timm.create_model(model_name, pretrained=True, num_classes=1000)
    #
    # # 输出模型的信息并导出到txt文件
    # with open("model_info.txt", "w") as f:
    #     sys.stdout = f
    #     pprint(m)
    #
    # # 恢复标准输出
    # sys.stdout = sys.__stdout__
    # # 获取分类头信息（也可在模型信息的最后一行的head条目看到）
    # classifier = m.get_classifier()
    # print(classifier)


if __name__ == '__main__':
    main()
